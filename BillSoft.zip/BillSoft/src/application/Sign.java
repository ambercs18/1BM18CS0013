package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//import com.mysql.jdbc.PreparedStatement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class Sign {
	@FXML
	TextField fn;
	@FXML
	TextField ln;
	@FXML
	TextField em;
	@FXML
	TextField pass;
	@FXML
	AnchorPane root;
	public void check(ActionEvent ev) throws ClassNotFoundException, SQLException, IOException
	{
		String a=fn.getText();
		String b=ln.getText();
		String c=em.getText();
		String d=pass.getText();
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ab","root","arijit@dhoni");
		String s="insert into supplier(fname,lname,email,pass) values (?,?,?,?)";
		PreparedStatement st= con.prepareStatement(s);
		st.setString(1,a);
		st.setString(2,b);
		st.setString(3,c);
		st.setString(4,d);
		st.executeUpdate();
		AnchorPane ap=FXMLLoader.load(getClass().getResource("/application/newCust.fxml"));
		root.getChildren().setAll(ap);
		
	}



}
