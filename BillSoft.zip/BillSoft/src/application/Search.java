package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class Search {
	@FXML
	TableView table;
	@FXML
	TextField ph;
	public void fun(ActionEvent ev) throws ClassNotFoundException, SQLException
	{
		String no=ph.getText();
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","arijit@dhoni");
	    Statement s=con.createStatement();
	    ResultSet rt=s.executeQuery("select * from Customer where cphone="+no);
	    while(rt.next())
	    {
	    	System.out.print(rt.getString(2));
	    }
	}
	

}
