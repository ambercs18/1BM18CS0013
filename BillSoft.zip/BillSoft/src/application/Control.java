package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Control {
	@FXML
	Label msg;
	@FXML
	TextField user;
	@FXML
	TextField pass;
	public void check(ActionEvent ev) throws IOException, ClassNotFoundException, SQLException
	{
		if(check(user.getText(), pass.getText()))
		{
			Parent root=FXMLLoader.load(getClass().getResource("/application/Wel.fxml"));
			Scene scene = new Scene(root,400,400);
			Stage primaryStage=new Stage();
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		}
		else
			msg.setText("Fail");
	}
	public void signup(ActionEvent ev) throws IOException
	{
		Parent root=FXMLLoader.load(getClass().getResource("/application/Signup.fxml"));
		Scene scene = new Scene(root,400,400);
		Stage primaryStage=new Stage();
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	public static boolean check(String n,String p) throws SQLException, ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ab","root","arijit@dhoni");
	    Statement s=con.createStatement();
	    ResultSet rt=s.executeQuery("select * from supplier");
	    while(rt.next())
	    {
	    int pass=rt.getInt(1);
	    String nm=rt.getString(2);
	    if(p.equals(Integer.toString(pass))&&n.equals(nm))
	    	return true;
	    }
	    return false;
	}

}
